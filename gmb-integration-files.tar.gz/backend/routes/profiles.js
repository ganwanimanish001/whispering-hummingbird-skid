/**
 * GMB Profiles API Routes
 * Endpoints for fetching and managing business profiles
 */

const express = require('express');
const GmbService = require('../services/gmbService');
const router = express.Router();

// Middleware to verify access token
const verifyToken = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }
  req.accessToken = token;
  next();
};

/**
 * GET /api/profiles
 * Fetch all GMB profiles for the authenticated user
 */
router.get('/', verifyToken, async (req, res) => {
  try {
    const profiles = await GmbService.getAllProfiles(req.accessToken);
    res.json({ profiles });
  } catch (error) {
    console.error('Error fetching profiles:', error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * GET /api/profiles/:profileId
 * Fetch details for a specific profile
 */
router.get('/:profileId', verifyToken, async (req, res) => {
  try {
    const { profileId } = req.params;
    const details = await GmbService.getLocationDetails(req.accessToken, profileId);
    res.json(details);
  } catch (error) {
    console.error('Error fetching profile details:', error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * PUT /api/profiles/:profileId
 * Update profile information
 */
router.put('/:profileId', verifyToken, async (req, res) => {
  try {
    const { profileId } = req.params;
    const updateData = req.body;

    const updated = await GmbService.updateLocation(req.accessToken, profileId, updateData);
    res.json(updated);
  } catch (error) {
    console.error('Error updating profile:', error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * GET /api/profiles/:profileId/reviews
 * Fetch reviews for a specific profile
 */
router.get('/:profileId/reviews', verifyToken, async (req, res) => {
  try {
    const { profileId } = req.params;
    const reviews = await GmbService.getReviews(req.accessToken, profileId);
    res.json({ reviews });
  } catch (error) {
    console.error('Error fetching reviews:', error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * POST /api/profiles/:profileId/posts
 * Create a new post for a profile
 */
router.post('/:profileId/posts', verifyToken, async (req, res) => {
  try {
    const { profileId } = req.params;
    const postData = req.body;

    const post = await GmbService.createPost(req.accessToken, profileId, postData);
    res.json(post);
  } catch (error) {
    console.error('Error creating post:', error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * POST /api/profiles/:profileId/reviews/:reviewId/reply
 * Reply to a review
 */
router.post('/:profileId/reviews/:reviewId/reply', verifyToken, async (req, res) => {
  try {
    const { profileId, reviewId } = req.params;
    const { comment } = req.body;

    if (!comment) {
      return res.status(400).json({ error: 'Reply comment required' });
    }

    const reviewName = `${profileId}/reviews/${reviewId}`;
    const reply = await GmbService.replyToReview(req.accessToken, reviewName, comment);
    res.json(reply);
  } catch (error) {
    console.error('Error replying to review:', error);
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;

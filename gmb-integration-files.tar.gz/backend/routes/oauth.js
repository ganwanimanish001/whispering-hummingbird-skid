/**
 * OAuth 2.0 Handler for Google Business Profile API
 * Handles authentication, token exchange, and refresh token management
 */

const express = require('express');
const axios = require('axios');
const router = express.Router();

// Environment variables
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET;
const REDIRECT_URI = process.env.GOOGLE_REDIRECT_URI || 'http://localhost:3001/api/oauth/callback';
const GOOGLE_AUTH_URL = 'https://accounts.google.com/o/oauth2/v2/auth';
const GOOGLE_TOKEN_URL = 'https://oauth2.googleapis.com/token';

// OAuth scopes required for GMB API
const SCOPES = [
  'https://www.googleapis.com/auth/business.manage',
  'https://www.googleapis.com/auth/userinfo.email',
  'https://www.googleapis.com/auth/userinfo.profile'
];

/**
 * Step 1: Generate OAuth authorization URL
 * Frontend redirects user to this URL to sign in with Google
 */
router.get('/auth-url', (req, res) => {
  try {
    const params = new URLSearchParams({
      client_id: GOOGLE_CLIENT_ID,
      redirect_uri: REDIRECT_URI,
      response_type: 'code',
      scope: SCOPES.join(' '),
      access_type: 'offline',
      prompt: 'consent' // Force consent screen to ensure refresh token
    });

    const authUrl = `${GOOGLE_AUTH_URL}?${params.toString()}`;
    res.json({ authUrl });
  } catch (error) {
    console.error('Error generating auth URL:', error);
    res.status(500).json({ error: 'Failed to generate authorization URL' });
  }
});

/**
 * Step 2: Handle OAuth callback
 * Google redirects user here after authentication
 */
router.get('/callback', async (req, res) => {
  try {
    const { code, error } = req.query;

    if (error) {
      return res.status(400).json({ error: `OAuth error: ${error}` });
    }

    if (!code) {
      return res.status(400).json({ error: 'No authorization code received' });
    }

    // Exchange authorization code for tokens
    const tokenResponse = await axios.post(GOOGLE_TOKEN_URL, {
      client_id: GOOGLE_CLIENT_ID,
      client_secret: GOOGLE_CLIENT_SECRET,
      code,
      grant_type: 'authorization_code',
      redirect_uri: REDIRECT_URI
    });

    const { access_token, refresh_token, expires_in } = tokenResponse.data;

    // Get user info
    const userResponse = await axios.get(
      'https://www.googleapis.com/oauth2/v2/userinfo',
      { headers: { Authorization: `Bearer ${access_token}` } }
    );

    const userData = {
      googleId: userResponse.data.id,
      email: userResponse.data.email,
      name: userResponse.data.name,
      picture: userResponse.data.picture,
      accessToken: access_token,
      refreshToken: refresh_token,
      expiresIn: expires_in,
      tokenExpiry: new Date(Date.now() + expires_in * 1000)
    };

    // TODO: Save tokens to database securely
    // For now, return to frontend to store in secure HTTP-only cookie
    // In production, store refresh_token in database and only send access_token to frontend

    res.redirect(`/oauth-success?token=${Buffer.from(JSON.stringify(userData)).toString('base64')}`);
  } catch (error) {
    console.error('OAuth callback error:', error);
    res.status(500).json({ error: 'Failed to exchange authorization code' });
  }
});

/**
 * Refresh access token using refresh token
 * Call this when access token expires
 */
router.post('/refresh-token', async (req, res) => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      return res.status(400).json({ error: 'Refresh token required' });
    }

    const tokenResponse = await axios.post(GOOGLE_TOKEN_URL, {
      client_id: GOOGLE_CLIENT_ID,
      client_secret: GOOGLE_CLIENT_SECRET,
      refresh_token: refreshToken,
      grant_type: 'refresh_token'
    });

    const { access_token, expires_in } = tokenResponse.data;

    res.json({
      accessToken: access_token,
      expiresIn: expires_in,
      tokenExpiry: new Date(Date.now() + expires_in * 1000)
    });
  } catch (error) {
    console.error('Token refresh error:', error);
    res.status(500).json({ error: 'Failed to refresh access token' });
  }
});

/**
 * Revoke access token
 * Call this when user logs out
 */
router.post('/revoke-token', async (req, res) => {
  try {
    const { accessToken } = req.body;

    if (!accessToken) {
      return res.status(400).json({ error: 'Access token required' });
    }

    await axios.post('https://oauth2.googleapis.com/revoke', null, {
      params: { token: accessToken }
    });

    res.json({ success: true, message: 'Token revoked successfully' });
  } catch (error) {
    console.error('Token revocation error:', error);
    res.status(500).json({ error: 'Failed to revoke token' });
  }
});

module.exports = router;

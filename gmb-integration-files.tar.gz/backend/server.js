/**
 * GMB AI Backend Server
 * Express server with OAuth 2.0 and GMB API integration
 */

const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
require('dotenv').config();

// Import routes
const oauthRoutes = require('./routes/oauth');
const profileRoutes = require('./routes/profiles');

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Routes
app.use('/api/oauth', oauthRoutes);
app.use('/api/profiles', profileRoutes);

// OAuth callback success page
app.get('/oauth-success', (req, res) => {
  const token = req.query.token;
  // Redirect to frontend with token
  res.redirect(`http://localhost:5173/settings?token=${token}`);
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', message: 'GMB API server is running' });
});

// Error handling
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(500).json({ error: err.message || 'Internal server error' });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 GMB API Server running on port ${PORT}`);
  console.log(`📍 OAuth callback: http://localhost:${PORT}/api/oauth/callback`);
  console.log(`🔗 Frontend: http://localhost:5173`);
});

/**
 * Google Business Profile API Service
 * Handles all interactions with the GMB API
 */

const axios = require('axios');

const GMB_API_BASE = 'https://mybusinessaccountmanagement.googleapis.com/v1';
const GMB_BUSINESS_INFO_BASE = 'https://mybusinessbusinessinformation.googleapis.com/v1';

class GmbService {
  /**
   * Get all accounts accessible to the authenticated user
   */
  static async getAccounts(accessToken) {
    try {
      const response = await axios.get(`${GMB_API_BASE}/accounts`, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'X-GOOG-API-FORMAT-VERSION': '2'
        }
      });

      return response.data.accounts || [];
    } catch (error) {
      console.error('Error fetching accounts:', error.response?.data || error.message);
      throw new Error(`Failed to fetch GMB accounts: ${error.message}`);
    }
  }

  /**
   * Get all locations for a specific account
   */
  static async getLocations(accessToken, accountId) {
    try {
      const response = await axios.get(
        `${GMB_API_BASE}/accounts/${accountId}/locations`,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'X-GOOG-API-FORMAT-VERSION': '2'
          }
        }
      );

      return response.data.locations || [];
    } catch (error) {
      console.error('Error fetching locations:', error.response?.data || error.message);
      throw new Error(`Failed to fetch GMB locations: ${error.message}`);
    }
  }

  /**
   * Get detailed information about a specific location
   */
  static async getLocationDetails(accessToken, locationName) {
    try {
      const response = await axios.get(
        `${GMB_BUSINESS_INFO_BASE}/${locationName}`,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'X-GOOG-API-FORMAT-VERSION': '2'
          }
        }
      );

      return response.data;
    } catch (error) {
      console.error('Error fetching location details:', error.response?.data || error.message);
      throw new Error(`Failed to fetch location details: ${error.message}`);
    }
  }

  /**
   * Get all profiles with their details for a user
   * Returns a consolidated list of all accessible locations
   */
  static async getAllProfiles(accessToken) {
    try {
      const accounts = await this.getAccounts(accessToken);
      const profiles = [];

      // Fetch locations for each account
      for (const account of accounts) {
        try {
          const locations = await this.getLocations(accessToken, account.name);
          
          for (const location of locations) {
            const locationDetails = await this.getLocationDetails(accessToken, location.name);
            
            profiles.push({
              id: location.name,
              accountId: account.name,
              accountName: account.accountName,
              businessName: locationDetails.title || 'Unnamed Business',
              address: locationDetails.address?.formattedAddress || 'No address',
              phone: locationDetails.phoneNumbers?.[0] || 'No phone',
              website: locationDetails.websiteUri || '',
              rating: locationDetails.rating?.averageRating || 0,
              reviewCount: locationDetails.rating?.reviewCount || 0,
              photoCount: locationDetails.photos?.length || 0,
              postCount: locationDetails.posts?.length || 0,
              description: locationDetails.description || '',
              categories: locationDetails.categories || [],
              businessHours: locationDetails.businessHours || [],
              fullDetails: locationDetails
            });
          }
        } catch (error) {
          console.warn(`Failed to fetch locations for account ${account.name}:`, error.message);
          // Continue with next account
        }
      }

      return profiles;
    } catch (error) {
      console.error('Error fetching all profiles:', error.message);
      throw new Error(`Failed to fetch all GMB profiles: ${error.message}`);
    }
  }

  /**
   * Update location information
   */
  static async updateLocation(accessToken, locationName, updateData) {
    try {
      const response = await axios.patch(
        `${GMB_BUSINESS_INFO_BASE}/${locationName}`,
        updateData,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'X-GOOG-API-FORMAT-VERSION': '2'
          }
        }
      );

      return response.data;
    } catch (error) {
      console.error('Error updating location:', error.response?.data || error.message);
      throw new Error(`Failed to update location: ${error.message}`);
    }
  }

  /**
   * Create a new post for a location
   */
  static async createPost(accessToken, locationName, postData) {
    try {
      const response = await axios.post(
        `${GMB_BUSINESS_INFO_BASE}/${locationName}/localPosts`,
        postData,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'X-GOOG-API-FORMAT-VERSION': '2'
          }
        }
      );

      return response.data;
    } catch (error) {
      console.error('Error creating post:', error.response?.data || error.message);
      throw new Error(`Failed to create post: ${error.message}`);
    }
  }

  /**
   * Get reviews for a location
   */
  static async getReviews(accessToken, locationName) {
    try {
      const response = await axios.get(
        `${GMB_BUSINESS_INFO_BASE}/${locationName}/reviews`,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'X-GOOG-API-FORMAT-VERSION': '2'
          }
        }
      );

      return response.data.reviews || [];
    } catch (error) {
      console.error('Error fetching reviews:', error.response?.data || error.message);
      throw new Error(`Failed to fetch reviews: ${error.message}`);
    }
  }

  /**
   * Reply to a review
   */
  static async replyToReview(accessToken, reviewName, replyText) {
    try {
      const response = await axios.post(
        `${GMB_BUSINESS_INFO_BASE}/${reviewName}:reply`,
        { comment: replyText },
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'X-GOOG-API-FORMAT-VERSION': '2'
          }
        }
      );

      return response.data;
    } catch (error) {
      console.error('Error replying to review:', error.response?.data || error.message);
      throw new Error(`Failed to reply to review: ${error.message}`);
    }
  }
}

module.exports = GmbService;

/**
 * Profile Service - Handles GMB Profile API calls
 */

import OAuthService, { Profile } from './oauthService';

const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3001/api';

class ProfileService {
  /**
   * Get all profiles for the authenticated user
   */
  static async getAllProfiles(): Promise<Profile[]> {
    try {
      const accessToken = OAuthService.getAccessToken();
      if (!accessToken) {
        throw new Error('No access token available');
      }

      const response = await fetch(`${API_BASE}/profiles`, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch profiles: ${response.statusText}`);
      }

      const data = await response.json();
      return data.profiles || [];
    } catch (error) {
      console.error('Error fetching profiles:', error);
      throw error;
    }
  }

  /**
   * Get details for a specific profile
   */
  static async getProfileDetails(profileId: string): Promise<Profile> {
    try {
      const accessToken = OAuthService.getAccessToken();
      if (!accessToken) {
        throw new Error('No access token available');
      }

      const response = await fetch(`${API_BASE}/profiles/${profileId}`, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch profile details: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error fetching profile details:', error);
      throw error;
    }
  }

  /**
   * Update profile information
   */
  static async updateProfile(profileId: string, updateData: any): Promise<any> {
    try {
      const accessToken = OAuthService.getAccessToken();
      if (!accessToken) {
        throw new Error('No access token available');
      }

      const response = await fetch(`${API_BASE}/profiles/${profileId}`, {
        method: 'PUT',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(updateData)
      });

      if (!response.ok) {
        throw new Error(`Failed to update profile: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error updating profile:', error);
      throw error;
    }
  }

  /**
   * Get reviews for a profile
   */
  static async getReviews(profileId: string): Promise<any[]> {
    try {
      const accessToken = OAuthService.getAccessToken();
      if (!accessToken) {
        throw new Error('No access token available');
      }

      const response = await fetch(`${API_BASE}/profiles/${profileId}/reviews`, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch reviews: ${response.statusText}`);
      }

      const data = await response.json();
      return data.reviews || [];
    } catch (error) {
      console.error('Error fetching reviews:', error);
      throw error;
    }
  }

  /**
   * Create a new post
   */
  static async createPost(profileId: string, postData: any): Promise<any> {
    try {
      const accessToken = OAuthService.getAccessToken();
      if (!accessToken) {
        throw new Error('No access token available');
      }

      const response = await fetch(`${API_BASE}/profiles/${profileId}/posts`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(postData)
      });

      if (!response.ok) {
        throw new Error(`Failed to create post: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error creating post:', error);
      throw error;
    }
  }

  /**
   * Reply to a review
   */
  static async replyToReview(profileId: string, reviewId: string, comment: string): Promise<any> {
    try {
      const accessToken = OAuthService.getAccessToken();
      if (!accessToken) {
        throw new Error('No access token available');
      }

      const response = await fetch(`${API_BASE}/profiles/${profileId}/reviews/${reviewId}/reply`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ comment })
      });

      if (!response.ok) {
        throw new Error(`Failed to reply to review: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error replying to review:', error);
      throw error;
    }
  }
}

export default ProfileService;

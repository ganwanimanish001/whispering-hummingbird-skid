/**
 * OAuth Service - Handles Google OAuth authentication
 */

const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3001/api';

export interface GoogleUser {
  googleId: string;
  email: string;
  name: string;
  picture: string;
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
  tokenExpiry: string;
}

export interface Profile {
  id: string;
  accountId: string;
  accountName: string;
  businessName: string;
  address: string;
  phone: string;
  website: string;
  rating: number;
  reviewCount: number;
  photoCount: number;
  postCount: number;
  description: string;
  categories: string[];
  businessHours: any[];
  fullDetails: any;
}

class OAuthService {
  /**
   * Get the OAuth authorization URL
   */
  static async getAuthUrl(): Promise<string> {
    try {
      const response = await fetch(`${API_BASE}/oauth/auth-url`);
      const data = await response.json();
      return data.authUrl;
    } catch (error) {
      console.error('Error getting auth URL:', error);
      throw new Error('Failed to get authorization URL');
    }
  }

  /**
   * Initiate OAuth flow
   */
  static async initiateOAuth(): Promise<void> {
    try {
      const authUrl = await this.getAuthUrl();
      window.location.href = authUrl;
    } catch (error) {
      console.error('OAuth initiation error:', error);
      throw error;
    }
  }

  /**
   * Get stored access token
   */
  static getAccessToken(): string | null {
    return localStorage.getItem('gmb_access_token');
  }

  /**
   * Get stored refresh token
   */
  static getRefreshToken(): string | null {
    return localStorage.getItem('gmb_refresh_token');
  }

  /**
   * Get stored user email
   */
  static getUserEmail(): string | null {
    return localStorage.getItem('gmb_user_email');
  }

  /**
   * Check if user is connected
   */
  static isConnected(): boolean {
    return !!this.getAccessToken();
  }

  /**
   * Save OAuth tokens
   */
  static saveTokens(userData: GoogleUser): void {
    localStorage.setItem('gmb_access_token', userData.accessToken);
    localStorage.setItem('gmb_refresh_token', userData.refreshToken);
    localStorage.setItem('gmb_user_email', userData.email);
    localStorage.setItem('gmb_user_name', userData.name);
    localStorage.setItem('gmb_token_expiry', userData.tokenExpiry);
  }

  /**
   * Refresh access token
   */
  static async refreshToken(): Promise<string> {
    try {
      const refreshToken = this.getRefreshToken();
      if (!refreshToken) {
        throw new Error('No refresh token available');
      }

      const response = await fetch(`${API_BASE}/oauth/refresh-token`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refreshToken })
      });

      const data = await response.json();
      localStorage.setItem('gmb_access_token', data.accessToken);
      localStorage.setItem('gmb_token_expiry', data.tokenExpiry);
      return data.accessToken;
    } catch (error) {
      console.error('Token refresh error:', error);
      throw new Error('Failed to refresh token');
    }
  }

  /**
   * Revoke token and logout
   */
  static async logout(): Promise<void> {
    try {
      const accessToken = this.getAccessToken();
      if (accessToken) {
        await fetch(`${API_BASE}/oauth/revoke-token`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ accessToken })
        });
      }
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      this.clearTokens();
    }
  }

  /**
   * Clear all stored tokens
   */
  static clearTokens(): void {
    localStorage.removeItem('gmb_access_token');
    localStorage.removeItem('gmb_refresh_token');
    localStorage.removeItem('gmb_user_email');
    localStorage.removeItem('gmb_user_name');
    localStorage.removeItem('gmb_token_expiry');
  }
}

export default OAuthService;

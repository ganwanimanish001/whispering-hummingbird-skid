/**
 * Profile Selector Component
 */

import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import ProfileService, { Profile } from '@/services/profileService';
import { Loader2, Star } from 'lucide-react';

interface ProfileSelectorProps {
  onProfileSelect: (profile: Profile) => void;
  onError?: (error: Error) => void;
}

const ProfileSelector: React.FC<ProfileSelectorProps> = ({ onProfileSelect, onError }) => {
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [selectedProfile, setSelectedProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchProfiles = async () => {
      try {
        setLoading(true);
        setError(null);
        const fetchedProfiles = await ProfileService.getAllProfiles();
        setProfiles(fetchedProfiles);

        if (fetchedProfiles.length > 0) {
          setSelectedProfile(fetchedProfiles[0]);
          onProfileSelect(fetchedProfiles[0]);
        }
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Failed to fetch profiles';
        setError(errorMessage);
        onError?.(new Error(errorMessage));
      } finally {
        setLoading(false);
      }
    };

    fetchProfiles();
  }, [onProfileSelect, onError]);

  const handleProfileChange = (profile: Profile) => {
    setSelectedProfile(profile);
    onProfileSelect(profile);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-indigo-600" />
        <span className="ml-2 text-gray-600">Loading your business profiles...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700">
        {error}
      </div>
    );
  }

  if (profiles.length === 0) {
    return (
      <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg text-sm text-yellow-700">
        No business profiles found. Please make sure you have created a Google Business Profile.
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h3 className="text-sm font-semibold text-gray-900">Select Your Business Profile</h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {profiles.map((profile) => (
          <Card
            key={profile.id}
            className={`cursor-pointer transition-all ${
              selectedProfile?.id === profile.id
                ? 'border-indigo-600 bg-indigo-50'
                : 'border-gray-200 hover:border-indigo-300'
            }`}
            onClick={() => handleProfileChange(profile)}
          >
            <CardContent className="p-4">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h4 className="font-semibold text-gray-900">{profile.businessName}</h4>
                  <p className="text-xs text-gray-500 mt-1">{profile.address}</p>
                </div>
                {selectedProfile?.id === profile.id && (
                  <Badge className="bg-indigo-600">Selected</Badge>
                )}
              </div>

              <div className="space-y-2 mb-3">
                {profile.phone && (
                  <p className="text-xs text-gray-600">📞 {profile.phone}</p>
                )}
                {profile.website && (
                  <p className="text-xs text-gray-600">🌐 {profile.website}</p>
                )}
              </div>

              <div className="grid grid-cols-3 gap-2 pt-3 border-t border-gray-100">
                <div className="text-center">
                  <div className="flex items-center justify-center gap-1">
                    <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                    <span className="text-xs font-semibold">{profile.rating.toFixed(1)}</span>
                  </div>
                  <p className="text-xs text-gray-500">Rating</p>
                </div>
                <div className="text-center">
                  <p className="text-xs font-semibold">{profile.reviewCount}</p>
                  <p className="text-xs text-gray-500">Reviews</p>
                </div>
                <div className="text-center">
                  <p className="text-xs font-semibold">{profile.photoCount}</p>
                  <p className="text-xs text-gray-500">Photos</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default ProfileSelector;

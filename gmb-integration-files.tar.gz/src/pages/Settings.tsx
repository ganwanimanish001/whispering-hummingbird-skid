"use client";

import React, { useState, useEffect } from 'react';
import AppLayout from '@/components/layout/AppLayout';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  Building2, 
  MapPin, 
  Globe, 
  Phone, 
  Save,
  ShieldCheck,
  Key,
  LogOut,
  Loader2
} from 'lucide-react';
import { showSuccess, showLoading, dismissToast, showError } from '@/utils/toast';
import GoogleSignIn from '@/components/auth/GoogleSignIn';
import ProfileSelector from '@/components/auth/ProfileSelector';
import OAuthService from '@/services/oauthService';
import ProfileService, { Profile } from '@/services/profileService';
import { cn } from '@/lib/utils';

const Settings = () => {
  const [isConnected, setIsConnected] = useState(false);
  const [selectedProfile, setSelectedProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(false);
  const [userEmail, setUserEmail] = useState('');
  
  const [businessData, setBusinessData] = useState({
    name: '',
    category: '',
    address: '',
    website: '',
    phone: '',
    description: ''
  });

  const [aiPreferences, setAiPreferences] = useState({
    tone: 'Professional',
    autoRespond: false
  });

  // Check for OAuth callback on mount
  useEffect(() => {
    const checkOAuthCallback = async () => {
      const params = new URLSearchParams(window.location.search);
      const token = params.get('token');

      if (token) {
        try {
          const userData = JSON.parse(atob(token));
          OAuthService.saveTokens(userData);
          setIsConnected(true);
          setUserEmail(userData.email);
          window.history.replaceState({}, document.title, '/settings');
          showSuccess('Successfully connected to Google Business Profile!');
        } catch (error) {
          console.error('Error processing OAuth callback:', error);
          showError('Failed to process authentication');
        }
      } else {
        // Check if token exists in localStorage
        const storedToken = OAuthService.getAccessToken();
        if (storedToken) {
          setIsConnected(true);
          setUserEmail(OAuthService.getUserEmail() || '');
        }
      }
    };

    checkOAuthCallback();
  }, []);

  // Load profile data when profile is selected
  useEffect(() => {
    if (selectedProfile) {
      setBusinessData({
        name: selectedProfile.businessName,
        category: selectedProfile.categories?.[0] || '',
        address: selectedProfile.address,
        website: selectedProfile.website,
        phone: selectedProfile.phone,
        description: selectedProfile.description
      });
    }
  }, [selectedProfile]);

  const handleProfileSelect = (profile: Profile) => {
    setSelectedProfile(profile);
  };

  const handleSaveChanges = async () => {
    if (!selectedProfile) {
      showError('Please select a profile first');
      return;
    }

    try {
      setLoading(true);
      const toastId = showLoading('Saving your profile settings...');

      const updateData = {
        title: businessData.name,
        address: {
          formattedAddress: businessData.address
        },
        websiteUri: businessData.website,
        phoneNumbers: [businessData.phone],
        description: businessData.description
      };

      await ProfileService.updateProfile(selectedProfile.id, updateData);

      dismissToast(toastId);
      showSuccess('Business information updated successfully!');
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to save changes';
      showError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const handleDisconnect = async () => {
    if (window.confirm('Are you sure you want to disconnect your Google Business Profile?')) {
      try {
        setLoading(true);
        await OAuthService.logout();
        setIsConnected(false);
        setSelectedProfile(null);
        setUserEmail('');
        setBusinessData({
          name: '',
          category: '',
          address: '',
          website: '',
          phone: '',
          description: ''
        });
        showSuccess('Disconnected successfully');
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Failed to disconnect';
        showError(errorMessage);
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <AppLayout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
        <p className="text-gray-500 mt-1">Configure your Google Business Profile details and AI preferences.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          {/* GMB Connection Section */}
          <Card className="border-none shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg font-bold flex items-center gap-2">
                <ShieldCheck className="text-indigo-600" size={20} />
                Google Business Profile Connection
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {!isConnected ? (
                <div className="p-4 bg-blue-50 border border-blue-100 rounded-xl">
                  <p className="text-sm text-blue-900 mb-4">
                    Connect your Google Business Profile to get started with AI-powered management.
                  </p>
                  <GoogleSignIn
                    onSuccess={() => setIsConnected(true)}
                    onError={(error) => showError(error.message)}
                  />
                </div>
              ) : (
                <>
                  <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-xl flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                      <div>
                        <span className="text-sm font-medium text-emerald-800">Connected to Google Business Profile</span>
                        <p className="text-xs text-emerald-700 mt-1">{userEmail}</p>
                      </div>
                    </div>
                    <Button
                      onClick={handleDisconnect}
                      disabled={loading}
                      variant="outline"
                      size="sm"
                      className="text-xs rounded-lg border-red-200 text-red-700 hover:bg-red-100"
                    >
                      {loading ? (
                        <Loader2 className="h-3 w-3 animate-spin mr-1" />
                      ) : (
                        <LogOut className="h-3 w-3 mr-1" />
                      )}
                      Disconnect
                    </Button>
                  </div>

                  {/* Profile Selector */}
                  <ProfileSelector
                    onProfileSelect={handleProfileSelect}
                    onError={(error) => showError(error.message)}
                  />
                </>
              )}
            </CardContent>
          </Card>

          {/* Business Information Section */}
          {isConnected && selectedProfile && (
            <Card className="border-none shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-bold flex items-center gap-2">
                  <Building2 className="text-indigo-600" size={20} />
                  Business Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Business Name</Label>
                    <Input
                      id="name"
                      value={businessData.name}
                      onChange={(e) => setBusinessData({ ...businessData, name: e.target.value })}
                      className="rounded-xl border-gray-200"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="category">Primary Category</Label>
                    <Input
                      id="category"
                      value={businessData.category}
                      onChange={(e) => setBusinessData({ ...businessData, category: e.target.value })}
                      className="rounded-xl border-gray-200"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">Business Address</Label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3 text-gray-400" size={18} />
                    <Input
                      id="address"
                      value={businessData.address}
                      onChange={(e) => setBusinessData({ ...businessData, address: e.target.value })}
                      className="pl-10 rounded-xl border-gray-200"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="website">Website URL</Label>
                    <div className="relative">
                      <Globe className="absolute left-3 top-3 text-gray-400" size={18} />
                      <Input
                        id="website"
                        value={businessData.website}
                        onChange={(e) => setBusinessData({ ...businessData, website: e.target.value })}
                        className="pl-10 rounded-xl border-gray-200"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-3 text-gray-400" size={18} />
                      <Input
                        id="phone"
                        value={businessData.phone}
                        onChange={(e) => setBusinessData({ ...businessData, phone: e.target.value })}
                        className="pl-10 rounded-xl border-gray-200"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Business Description (SEO Optimized)</Label>
                  <Textarea
                    id="description"
                    value={businessData.description}
                    onChange={(e) => setBusinessData({ ...businessData, description: e.target.value })}
                    className="min-h-[120px] rounded-xl border-gray-200"
                  />
                  <p className="text-xs text-gray-400">This description will be used by the AI to generate relevant posts and responses.</p>
                </div>
              </CardContent>
              <CardFooter className="bg-gray-50/50 border-t border-gray-100 p-6 rounded-b-xl">
                <Button
                  onClick={handleSaveChanges}
                  disabled={loading}
                  className="bg-indigo-600 hover:bg-indigo-700 rounded-xl ml-auto"
                >
                  {loading ? (
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  ) : (
                    <Save size={18} className="mr-2" />
                  )}
                  {loading ? 'Saving...' : 'Save Changes'}
                </Button>
              </CardFooter>
            </Card>
          )}
        </div>

        {/* AI Preferences Sidebar */}
        {isConnected && selectedProfile && (
          <div className="space-y-6">
            <Card className="border-none shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg font-bold flex items-center gap-2">
                  <Key className="text-indigo-600" size={20} />
                  AI Preferences
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <Label>Tone of Voice</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {['Professional', 'Friendly', 'Casual', 'Excited'].map((tone) => (
                      <Button
                        key={tone}
                        variant={aiPreferences.tone === tone ? 'default' : 'outline'}
                        className={cn(
                          "text-xs rounded-xl h-9",
                          aiPreferences.tone === tone ? "bg-indigo-600" : "border-gray-200"
                        )}
                        onClick={() => setAiPreferences({ ...aiPreferences, tone })}
                      >
                        {tone}
                      </Button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <Label>Auto-Response</Label>
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                    <span className="text-sm text-gray-600">Respond to 5-star reviews</span>
                    <button
                      onClick={() => setAiPreferences({ ...aiPreferences, autoRespond: !aiPreferences.autoRespond })}
                      className={cn(
                        "w-10 h-5 rounded-full relative transition-colors",
                        aiPreferences.autoRespond ? "bg-indigo-600" : "bg-gray-300"
                      )}
                    >
                      <div
                        className={cn(
                          "absolute top-1 w-3 h-3 bg-white rounded-full transition-transform",
                          aiPreferences.autoRespond ? "right-1" : "left-1"
                        )}
                      />
                    </button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </AppLayout>
  );
};

export default Settings;
